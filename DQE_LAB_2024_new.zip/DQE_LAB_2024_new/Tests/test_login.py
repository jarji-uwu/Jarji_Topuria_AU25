import os
import sys
import yaml
import pytest

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from Pages.incomeStatementsReportPage import IncomeStatementsReportPage


def get_selenium_config(config_name):
    module_dir = os.path.dirname(os.path.abspath(sys.modules[__name__].__file__))
    parent_dir = os.path.dirname(module_dir)
    with open(os.path.join(parent_dir, 'Configs', config_name), 'r') as stream:
        config = yaml.safe_load(stream)
    return config['global']


@pytest.fixture(scope="function")
def open_income_statements_report_webpage():
    report_uri = get_selenium_config('config_selenium.yaml')['report_uri']

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.maximize_window()
    driver.get(report_uri)

    yield driver

    driver.quit()


def test_01_open_income_statement(open_income_statements_report_webpage):
    driver = open_income_statements_report_webpage
    page = IncomeStatementsReportPage(driver, 5)

    # ✅ Check 1 — page title
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    # wait until page has a header → means page loaded
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, "h1"))
    )

    assert "Microsoft" in driver.title

    # ✅ Check 2 — main header exists
    assert "Earnings Release" in page.get_main_header()

    # ✅ Check 3 — section visible
    assert page.is_income_section_visible()